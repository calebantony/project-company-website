<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('home');
	}
	
	public function services()
	{
    $this->load->view('services');   
	}

	public function about()
	{
    $this->load->view('about');   
	}
	public function login()
	{
		$temp['us']="";

    $this->load->view('Loginform',$temp);   
	}
	
	public function contact()
	{
    $this->load->view('contact');   	
	}		

	public function demo()
	{
    $this->load->view('demoview');   	
	}	
	
	public function admindash()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
		$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count2();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();
		$info4 =$this->data_model->get_count5();  
		$info5 =$this->data_model->get_count6();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3,'planet4' => $info4,'planet5' => $info5);
	  
		$this->load->view('admindash',$data);
	}
	}	


	public function empdash()
	{
		if(!$this->session->userdata('employemail'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{
		$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count2();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();
		$info4 =$this->data_model->get_count5();  
		$info5 =$this->data_model->get_count6();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3,'planet4' => $info4,'planet5' => $info5);
	  
		$this->load->view('employedash',$data);

	}	
}


	public function addstaff()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
    $this->load->view('adminaddstaff');   
	}	
	}	


	public function admineditform()
	{
    $this->load->view('adminstaffeditform');   	
	}	


	public function admevent()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
    $this->load->view('adminevent');   	
	}
}
	
	
	public function cpayment()
	{
		if(!$this->session->userdata('user'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{
		$planet['payment'] = '0';
		$usrmail=$this->session->userdata('user');//was id 
		
		$this->load->model('data_model');


		 $usrdet=$this->data_model->getsrid($usrmail);
		 $id=$usrdet->srid;

		
		$data['track']=$this->data_model->custpaymnt($id);
		$this->load->view('custpayment',$data);
	
		
	}
}

	public function cpaychekout()
	{

	$id=$this->input->post('pymnt');
	echo $id;
	$planet['payment'] = $id;
    $this->load->view('custpaymentform',$planet);   
	}

	public function empprof()
	{

		if(!$this->session->userdata('employemail'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{
		$this->load->model('data_model');
		$emil=$this->session->userdata('employemail');
		//echo $emil;
		$emidt=$this->data_model->getempid($emil);
		$id=$emidt->empid;
	  
		
		$data['emp']=$this->data_model->get_data("employee");
		$data['updat']=$this->data_model->data_updat("employee",$id);
		$this->load->view('employeprofile',$data); 
	
	}	
	}

	
	public function admcalend()
	{
    $this->load->view('admincalender');   	
	}	

	public function custiket()
	{
		if(!$this->session->userdata('user'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{
    $this->load->view('custTicket');   	
	}	
}

	public function custiketdone()
	{
    $this->load->view('custticketSucess');   	
	}


	public function cusvietik()
	{
		if(!$this->session->userdata('user'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{
    $this->load->view('custviewticket');   	
	}
}

	public function cusvietikstatus()  //status  view load page
	{
		if(!$this->session->userdata('user'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{
    $this->load->view('custtickstatus');   	
	}
}

	public function custser()
	{
		if(!$this->session->userdata('user'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{
    $this->load->view('custservreq');   	
	}
}


	public function custdash()
	{
		if(!$this->session->userdata('user'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{

	$maile=$this->session->userdata('user');

	$this->load->model('data_model');
	$info['emp']=$this->data_model->get_tikid($maile);
	$this->load->view('custdash',$info);
	}
}


	public function signup()
	{
	$temp['us']="";

    $this->load->view('signup',$temp);   	
	}


	public function add()
	{
		$a=$this->input->post('usremail');
		$b=$this->input->post('remail');
		$email=$this->input->post('usremail');

		if($a==$b)
		{
			$data=array('name'=>$this->input->post('usrname'),
			'email'=>$this->input->post('usremail'),
			'password'=>$this->input->post('pass'),
			'utype'=>'c'
			// 'utype'=>$this->input->post('type')
			);







			$this->load->model('data_model');
			$res=$this->data_model->get_email($email);
			if($res==null)
			{
				$this->load->model('data_model');
		    	$this->data_model->insert_data("users",$data);
				$temp['us']="Your Account  Created Succesfully , Please Login ";
		        $this->load->view('Loginform',$temp);
			}
			else
			{
				echo "<script>alert('Email already exists please signin with a different one ')</script>";
				$temp['us']="";
				$this->load->view('signup',$temp);
			}


		}
		
	else
	{
	$temp['us']="Your Email  doesnt match eachother ";
	$this->load->view('signup',$temp);
	}
      
       
	}


	public function adminticket()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_data("ticket");
		$this->load->view('adminticket',$info);
   
	}
}


	public function showtick()
	{
		$tid=$this->input->post('tid');
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_Tick($tid);
		// echo $tid;

		if ( empty($info['emp']) ) 
		{
			$this->load->view('custsrnofound');
	
		}
		else
		{
			$this->load->view('custshotick',$info);
		}

		
    	
	}	




	public function cushowtickstatus()
	{
		$tid=$this->input->post('tid');
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_Tick($tid);
		// echo $tid;

		if ( empty($info['emp']) ) 
		{
			$this->load->view('custsrnofound');
	
		}
		else
		{
			$this->load->view('custticketstatusreslt',$info);
		}	
	}	




	public function showtickreply()
	{
		$tid=$this->uri->segment(3);
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_Tick($tid);
		// echo $tid;
		$this->load->view('admintikrep',$info);
		
	}	

	



	public function empevent()
	{
		if(!$this->session->userdata('employemail'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{

		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_data("evnttable");
   		 $this->load->view('employeevent',$info);
	
	}	
}


	public function del_evnt()             //delete
    {
        $id=$this->uri->segment(3);
        $this->load->model('data_model');
        $this->data_model->data_delevnt("evnttable",$id);
        header('location:'.base_url().'Welcome/empevent');
     }

	public function emplist()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_data("employee");
		$this->load->view('adminemplist',$info);
    	
	}	
}



	public function worklist()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->work_view();
		$this->load->view('adminworklist',$info);
    	
	}	
}


	public function billing()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->work_view();
		$this->load->view('adminbilling',$info);
    	
	}	
}

	public function calc_bill()             //delete
    {
        $srid=$this->uri->segment(3);
        $this->load->model('data_model');
        $info['emp']=$this->data_model->get_wrk($srid);

		$this->load->view('adminbillamount',$info);
		
       
     }



	 public function amountupdate()        
	 {
  
		 $wid=$this->input->post('wid');
		//$id=$this->uri->segment(3);
		 $data=array('wdate'=>$this->input->post('wdate'),
		 'wstatus'=>$this->input->post('wstatus'),
		 'empid'=>$this->input->post('empid'),
		 'srid'=>$this->input->post('srid'),
		 'pymnt'=>$this->input->post('pymnt')
		 );

		 $this->load->model('data_model');
		 $this->data_model->amount_update("work",$data,$wid);

		 $this->load->model('data_model');
		 $info['emp']=$this->data_model->work_view();
		 $this->load->view('adminbilling',$info);
	  //    header('location:'.base_url().'Login/admineditemp');
  
	 
  }


	public function empworklist()
	{
		if(!$this->session->userdata('employemail'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->work_view();
		$this->load->view('empworklist',$info);
    	
	}	
}



	public function empmywork()
	{
		if(!$this->session->userdata('employemail'))
		{
			$temp['us']="";

   		 $this->load->view('Loginform',$temp); 
		}
		else
		{
		$this->load->model('data_model');
		$emil=$this->session->userdata('employemail');
		//echo $emil;
		$emidt=$this->data_model->getempid($emil);
		$emid=$emidt->empid;
		//echo $emid;
		 $info['emp']=$this->data_model->mywork_view($emid);
	    $this->load->view('empmywork',$info);
    	
	}	
}

	public function empworkupdat()
	{
		$srid=$this->uri->segment(3);
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_wrk($srid);
		// echo $tid;
		$this->load->view('empmyworupd',$info);
		
	}	

	public function empwrkstsupdate()        
	{
 
		$wid=$this->input->post('wid');
	   //$id=$this->uri->segment(3);
		$data=array('wdate'=>$this->input->post('adate'),
		'wstatus'=>$this->input->post('status'),
		'empid'=>$this->input->post('empid'),
		'srid'=>$this->input->post('srid'),
		'pymnt'=>$this->input->post('pymnt')
		);

		$this->load->model('data_model');
		$this->data_model->amount_update("work",$data,$wid);

		$this->load->model('data_model');
		$emil=$this->session->userdata('employemail');
		//echo $emil;
		$emidt=$this->data_model->getempid($emil);
		$emid=$emidt->empid;
		//echo $emid;
		 $info['emp']=$this->data_model->mywork_view($emid);
	    $this->load->view('empmywork',$info);
	
 
	
 }

	public function admserreq()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_data("service");
		$this->load->view('adminserreqlst',$info);
    	
	}	
}




	

	public function empdelete()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_data("employee");
		$this->load->view('adminremovestaf',$info);
    	
	}	
}

	public function del_data()             //delete
    {
        $id=$this->uri->segment(3);
        $this->load->model('data_model');
		$id1=$this->data_model->get_empmail($id);
		$cid=$id1->email;
	//	echo $cid;
        $this->data_model->data_del("employee",$id);
		$this->data_model->usr_del("users",$cid);
        header('location:'.base_url().'Welcome/empdelete');
     }

	public function editemp()
	{
		if(!$this->session->userdata('adminemail'))
	{
	$temp['us']="";

   		 $this->load->view('Loginform',$temp);  
	}
	else
	{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_data("employee");
		$this->load->view('admineditemp',$info);
    	
	}
}	

	public function updat_data() //post
	{
		$id=$this->uri->segment(3);
		$this->load->model('data_model');
		// $data['cust']=$this->data_model->get_data("bill_detail");
		$data['emp']=$this->data_model->get_data("employee");
		$data['updat']=$this->data_model->data_updat("employee",$id);
		$this->load->view('adminstaffeditform',$data); 
   
   }



   public function updat_status() //post
   {
	$id=$this->input->post('tid');
//   $id=$this->uri->segment(3);
	$data=array('usrname'=>$this->input->post('name'),
	'usremail'=>$this->input->post('email'),
	'mobile'=>$this->input->post('phone'),
	'subject'=>$this->input->post('subj'),
	'department'=>$this->input->post('dept'),
	'service'=>$this->input->post('service'),
	'priority'=>$this->input->post('priority'),
	'message'=>$this->input->post('message'),
	'status'=>$this->input->post('status'),
	
	);
	$this->load->model('data_model');
	$this->data_model->data_updatestatus("ticket",$data,$id);
	
	$this->load->model('data_model');
	$info =$this->data_model->get_count1();   
	$info1 =$this->data_model->get_count2();  
	$info2 =$this->data_model->get_count3();  
	$info3 =$this->data_model->get_count4();
	$info4 =$this->data_model->get_count5();  
	$info5 =$this->data_model->get_count6();  
	
	
	$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3,'planet4' => $info4,'planet5' => $info5);
  
	$this->load->view('admindash',$data);
}

public function assignemp() //post
{
 $srid=$this->input->post('srid');

    $this->load->model('data_model');
    $data['emp']=$this->data_model->data_service("service",$srid);
	$data['bankdata'] = $this->data_model->getbanklist();
	$this->load->view('adminassignemp', $data);

}




public function updat_serreq() //load onto form 
	{
		$id=$this->uri->segment(3);
		$this->load->model('data_model');
		// $data['cust']=$this->data_model->get_data("bill_detail");
		$data['emp']=$this->data_model->get_data("service");
		$data['updat']=$this->data_model->data_service("service",$id);
		$this->load->view('adminserveeditform',$data); 
   
   }


public function cust_replay() //cust tick replay
{
 $id=$this->input->post('tid');
//   $id=$this->uri->segment(3);
 $data=array('usrname'=>$this->input->post('name'),
 'usremail'=>$this->input->post('email'),
 'mobile'=>$this->input->post('phone'),
 'subject'=>$this->input->post('subj'),
 'department'=>$this->input->post('dept'),
 'service'=>$this->input->post('service'),
 'priority'=>$this->input->post('priority'),
 'message'=>$this->input->post('message'),
 'status'=>'Customer replay',
 
 );
 $this->load->model('data_model');
 $this->data_model->data_updatestatus("ticket",$data,$id);


 $maile=$this->session->userdata('user');

	$this->load->model('data_model');
	$info['emp']=$this->data_model->get_tikid($maile);
	$this->load->view('custdash',$info);

}


public function admcustrepmesssfrm() //replay button code
   {
	   $tid=$this->input->post('tid');
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_Tick($tid);
		// echo $tid;
		$this->load->view('admintickrepmesg',$info);
}




public function admcustrep() // admin customer replay form submit code
{
 $id=$this->input->post('tid');
//   $id=$this->uri->segment(3);
 $data=array('usrname'=>$this->input->post('name'),
 'usremail'=>$this->input->post('email'),
 'mobile'=>$this->input->post('phone'),
 'subject'=>$this->input->post('subj'),
 'department'=>$this->input->post('dept'),
 'service'=>$this->input->post('service'),
 'priority'=>$this->input->post('priority'),
 'message'=>$this->input->post('message'),
 'status'=>$this->input->post('status'),
 );
 $this->load->model('data_model');
 $this->data_model->data_updatestatus("ticket",$data,$id);

 $this->load->model('data_model');
		$info['emp']=$this->data_model->get_data("ticket");
		$this->load->view('adminticket',$info);
}



   public function updat_cust()        //update
   {

	   $id=$this->input->post('hid');
	  //$id=$this->uri->segment(3);
	   $data=array('fname'=>$this->input->post('fname'),
	   'lname'=>$this->input->post('lname'),
	   'phone'=>$this->input->post('phone'),
	   'email'=>$this->input->post('email'),
	   'dob'=>$this->input->post('dob'),
	   'gender'=>$this->input->post('gender'),
	   'adr1'=>$this->input->post('adr1'),
	   'adr2'=>$this->input->post('adr2'),
	   'city'=>$this->input->post('city'),
	   'country'=>$this->input->post('country'),
	   'pcode'=>$this->input->post('pcode'),
	   'desig'=>$this->input->post('desig'),
	   'pass'=>$this->input->post('pass')
	   );
	   $this->load->model('data_model');
	   $this->data_model->data_update("employee",$data,$id);
	//    header('location:'.base_url().'Login/admineditemp');

	$this->load->model('data_model');
	$info['emp']=$this->data_model->get_data("employee");
	$this->load->view('admineditemp',$info);

}


public function updat_emppro()        //update
{

	$id=$this->input->post('hid');
   //$id=$this->uri->segment(3);
	$data=array('fname'=>$this->input->post('fname'),
	'lname'=>$this->input->post('lname'),
	'phone'=>$this->input->post('phone'),
	'email'=>$this->input->post('email'),
	'dob'=>$this->input->post('dob'),
	'gender'=>$this->input->post('gender'),
	'adr1'=>$this->input->post('adr1'),
	'adr2'=>$this->input->post('adr2'),
	'city'=>$this->input->post('city'),
	'country'=>$this->input->post('country'),
	'pcode'=>$this->input->post('pcode'),
	'desig'=>$this->input->post('desig'),
	'pass'=>$this->input->post('pass')
	);
	$this->load->model('data_model');
	$this->data_model->data_update("employee",$data,$id);
 //    header('location:'.base_url().'Login/admineditemp');

 $this->load->model('data_model');
 $emil=$this->session->userdata('employemail');
 //echo $emil;
 $emidt=$this->data_model->getempid($emil);
 $id=$emidt->empid;

 
 $data['emp']=$this->data_model->get_data("employee");
 $data['updat']=$this->data_model->data_updat("employee",$id);
 $this->load->view('employeprofile',$data); 
}




	
	public function log()
	{
		$id=$this->input->post('username');
        $pass=$this->input->post('pass');
        $this->load->model('data_model');
		
        $data['cust']=$this->data_model->get_user("users",$id,$pass,'c');
        $data['admin']=$this->data_model->get_user("users",$id,$pass,'a');
		$data['emp']=$this->data_model->get_user("users",$id,$pass,'e');
		
		 $this->session->set_userdata(array('uname'=>$id));


        if($data['cust']!=null)
        {  
		//	$_SESSION['c_email'] = $id;
			$this->session->set_userdata('user',$id);


			$maile=$this->session->userdata('user');

			$this->load->model('data_model');
			$info['emp']=$this->data_model->get_tikid($maile);
			$this->load->view('custdash',$info);

           
			
        }
        else if($data['admin']!=null)
        {
			$this->session->set_userdata('adminemail',$id);

			$this->load->model('data_model');
			$info =$this->data_model->get_count1();   
			$info1 =$this->data_model->get_count2();  
			$info2 =$this->data_model->get_count3();  
			$info3 =$this->data_model->get_count4();
			$info4 =$this->data_model->get_count5();  
			$info5 =$this->data_model->get_count6();  
			
			
			$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3,'planet4' => $info4,'planet5' => $info5);
		  
			$this->load->view('admindash',$data);

			
			
        }
		else if($data['emp']!=null)
        {
		
		$this->session->set_userdata('employemail',$id);

			
		$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count2();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();
		$info4 =$this->data_model->get_count5();  
		$info5 =$this->data_model->get_count6();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3,'planet4' => $info4,'planet5' => $info5);
	  
		$this->load->view('employedash',$data);

        }

        else
        {
			$temp['us']="incorrect email/password combination";

			$this->load->view('Loginform',$temp);   
        }
	}



	public function evntreg()
	{
		// $email=$this->input->post('email');
		$data1=array('evntname'=>$this->input->post('evntitle'),
        'evnttime'=>$this->input->post('evntime'),
        'evntdesc'=>$this->input->post('evndesc'),
        'evntdate'=>$this->input->post('evnd')
	
        );

		
        $this->load->model('data_model');
		$this->data_model->insert_data("evnttable",$data1);
		
			
			

		$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count2();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();
		$info4 =$this->data_model->get_count5();  
		$info5 =$this->data_model->get_count6();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3,'planet4' => $info4,'planet5' => $info5);
	  
		$this->load->view('admindash',$data);
		
		
	}


	public function tickreg()
	{
		// $email=$this->input->post('email');
		$data1=array('usrname'=>$this->input->post('name'),
        'usremail'=>$this->input->post('email'),
        'mobile'=>$this->input->post('phone'),
        'subject'=>$this->input->post('subj'),
		'department'=>$this->input->post('dept'),
		'service'=>$this->input->post('service'),
		'message'=>$this->input->post('message'),
		'status'=>"open"
		
        );
		
        $this->load->model('data_model');
		$this->data_model->insert_data("ticket",$data1);
		
				
	}


	public function tickregister()
	{

	$data1=array('usrname'=>$this->input->post('name'),
        'usremail'=>$this->input->post('email'),
        'mobile'=>$this->input->post('phone'),
        'subject'=>$this->input->post('subj'),
		'department'=>$this->input->post('dept'),
		'service'=>$this->input->post('service'),
        'priority'=>$this->input->post('priority'),
		'message'=>$this->input->post('message'),
		'status'=>"open",
        'atchment'=>"Null"
		
        );
		
        $this->load->model('data_model');
		$this->data_model->insert_data("ticket",$data1);

        $usrmail=$this->input->post('email');
        $mobile=$this->input->post('phone');
        $sub=$this->input->post('subj');
		$dept=$this->input->post('dept');
     

      //  $info['emp']=$this->data_model->get_idd($sub,$dept,$mobile,$usrmail);
		
		$info =$this->data_model->get_ticketid();  
		$data = array('planet' => $info);
	  
		$this->load->view('custticketSucess',$data);


       // $this->load->view('custticketSucess',$info);
	}






	public function empreg()
	{
		// $email=$this->input->post('email');
		$data1=array('fname'=>$this->input->post('fname'),
        'lname'=>$this->input->post('lname'),
        'phone'=>$this->input->post('phone'),
        'email'=>$this->input->post('email'),
		'dob'=>$this->input->post('dob'),
		'gender'=>$this->input->post('gender'),
		'adr1'=>$this->input->post('adr1'),
		'adr2'=>$this->input->post('adr2'),
		'city'=>$this->input->post('city'),
		'country'=>$this->input->post('country'),
		'pcode'=>$this->input->post('pcode'),
		'desig'=>$this->input->post('desig'),
		'pass'=>$this->input->post('pass')
        );

		$data2=array('name'=>$this->input->post('fname'),
        'email'=>$this->input->post('email'),
        'password'=>$this->input->post('pass'),
        'utype'=>'e'
        );
		
        $this->load->model('data_model');
		// $res=$this->data_model->get_email($email);
		// if($res==null)
		// {
			$this->data_model->insert_data("employee",$data1);
			$this->data_model->insert_data("users",$data2);
			
			

			$this->load->model('data_model');
			$info =$this->data_model->get_count1();   
			$info1 =$this->data_model->get_count2();  
			$info2 =$this->data_model->get_count3();  
			$info3 =$this->data_model->get_count4();
			$info4 =$this->data_model->get_count5();  
			$info5 =$this->data_model->get_count6();  
			
			
			$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3,'planet4' => $info4,'planet5' => $info5);
		  
			$this->load->view('admindash',$data);
		
       

		
	}







	public function workreg()
	{
 
		

		$empid=$this->input->post('empid');
		$srid=$this->input->post('srid');
		$dat=$this->input->post('adate');
		
		$data=array(
		'wstatus'=>'pending',
		'empid'=>$empid,  'srid'=>$srid , 'wdate'=>$dat);


        $this->load->model('data_model');
        $this->data_model->insert_data("work",$data);
		
		$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count2();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();
		$info4 =$this->data_model->get_count5();  
		$info5 =$this->data_model->get_count6();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3,'planet4' => $info4,'planet5' => $info5);
	  
		$this->load->view('admindash',$data);
	}






	public function cuserreg()
	{
		
		$data1=array('subj'=>$this->input->post('subj'),
        'stype'=>$this->input->post('relaser'),
        'phone'=>$this->input->post('phone'),
        'email'=>$this->input->post('email'),
		'descrip'=>$this->input->post('descr'),
        );
	
        $this->load->model('data_model');
		
		$this->data_model->insert_data("service",$data1);
			
		$sub=$this->input->post('subj');
        $mobile=$this->input->post('phone');
        $mail=$this->input->post('email');
      //  $info['emp']=$this->data_model->get_seridd($sub,$mail,$mobile);
		
		$info =$this->data_model->get_serid();  
		$data = array('planet' => $info);
	  
		$this->load->view('custservsucess',$data);

       // $this->load->view('custservsucess',$info);
	}




	public function adminlogout()  
    {  

		//$this->session->sess_destroy();
		$this->session->unset_userdata('adminemail');
		$temp['us']="";

   		 $this->load->view('Loginform',$temp);   
			//redirect('admindash');
    }  

	public function custlogout()  
    {  

		//$this->session->sess_destroy();
		$this->session->unset_userdata('user');
		$temp['us']="";

   		 $this->load->view('Loginform',$temp);   
			
    }  


	public function emplogout()  
    {  

		//$this->session->sess_destroy();
		$this->session->unset_userdata('employemail');
		$temp['us']="";

   		 $this->load->view('Loginform',$temp);   
			
    }  



}

