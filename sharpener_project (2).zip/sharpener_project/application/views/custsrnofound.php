<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>sharpenertechnologyservices</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url();?>assets/assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="<?php echo base_url();?>assets/assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="<?php echo base_url();?>assets/assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url();?>assets/assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url();?>assets/assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

	
<link rel="shortcut icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">


</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="<?php echo base_url();?>assets/assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
            &nbsp;
            <br>
            &nbsp;

				<!-- <span style="font-size: 25px; font-weight: bold;"><label style="color: #007bff">S</label>harpener <br> <label style="color: #007bff">T</label>echnology</span> -->
            </div>

            <ul class="nav">
            <li >
                    <a href="<?php echo base_url();?>Welcome/custdash">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/custser">
                    <i class="pe-7s-note2"></i>
                        <p> Service Request  </p>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>Welcome/custiket">
                    <i class="pe-7s-ticket"></i>
                        <p>Open Ticket </p>
                    </a>
                </li>
                <li class="active">
                    <a href="<?php echo base_url();?>Welcome/cusvietik">
                    <i class="pe-7s-bandaid"></i>
                        <p>View  tickets </p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/cusvietikstatus">
                        <i class="pe-7s-timer"></i>
                        <p>Ticket status</p>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>Welcome/cpayment">
                        <i class="pe-7s-wallet"></i>
                        <p>Payments</p>
                    </a>
                </li>
               
				<!-- <li class="active-pro">
                    <a href="upgrade.html">
                        <i class="pe-7s-rocket"></i>
                        <p>Upgrade to PRO</p>
                    </a>
                </li> -->
            </ul>
    	</div>
    </div>

    <div class="main-panel">
    <?php include('adminheadercust.php');?>

      














        &nbsp;
            <br>
            <br>
            
            &nbsp;
        
      
            <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 style=" font-family:verdana;" class="title"> Ticket  Details  </h4>
                            </div>
                            <div class="content">
                           

                          
                                <form method="POST" action="<?php echo base_url();?>Welcome/custdash">
                                 

                                   

                                &nbsp;
           
            
            
            &nbsp;
                                

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label ><b> No Records Found </b> </label>
                                            
                                            </div>
                                        </div>
                                    </div>

                                    &nbsp;
            <br>
            
            
            &nbsp;

                                    <button type="submit" value="Upload Image" class="btn btn-danger">&nbsp; Back to Home &nbsp; </button>
                                    <div class="clearfix"></div>
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                   

                </div>
            </div>
        </div>
              

            


       

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="<?php echo base_url();?>assets/assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="<?php echo base_url();?>assets/assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="<?php echo base_url();?>assets/assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="<?php echo base_url();?>assets/assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="<?php echo base_url();?>assets/assets/js/demo.js"></script>

	
</html>
