<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>

<script src="<?php echo base_url();?>js/popper.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.js"></script>
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.fancybox.js"></script>
<script src="<?php echo base_url();?>js/appear.js"></script>
<script src="<?php echo base_url();?>js/parallax.min.js"></script>
<script src="<?php echo base_url();?>js/tilt.jquery.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.paroller.min.js"></script>
<script src="<?php echo base_url();?>js/owl.js"></script>
<script src="<?php echo base_url();?>js/wow.js"></script>
<script src="<?php echo base_url();?>js/nav-tool.js"></script>
<script src="<?php echo base_url();?>js/jquery-ui.js"></script>
<script src="<?php echo base_url();?>js/script.js"></script>
<script src="<?php echo base_url();?>js/color-settings.js"></script>




</body>

<!-- Mirrored from expert-themes.com/html/globex/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 19 Nov 2020 04:40:19 GMT -->

<!-- Mirrored from sharpenertechnologyservices.com/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 21 Nov 2021 14:51:55 GMT -->
</html>