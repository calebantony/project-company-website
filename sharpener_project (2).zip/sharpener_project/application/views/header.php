<!DOCTYPE html>
<html>

<!-- Mirrored from sharpenertechnologyservices.com/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 21 Nov 2021 14:50:17 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="utf-8">
<title>sharpenertechnologyservices</title><!-- Stylesheets -->
<link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>css/responsive.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&amp;family=Nunito+Sans:wght@300;600;700;800;900&amp;display=swap" rel="stylesheet">

<!-- Color Switcher Mockup -->
<link href="<?php echo base_url();?>css/color-switcher-design.css" rel="stylesheet">

<!-- Color Themes -->
<link id="theme-color-file" href="<?php echo base_url();?>css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body class="hidden-bar-wrapper">

<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
 	<!-- Main Header-->
    <header class="main-header header-style-one">
    	
		<!-- Header Top -->
        <div class="header-top">
            <div class="auto-container">
                <div class="clearfix">
					<!-- Top Left -->
					<div class="top-left">
						<!-- Info List -->
						<ul class="info-list">
							<li><a href="mailto:info@webmail.com"><span class="icon flaticon-email"></span>support@sharpnertechnologies.com</a></li>
							<li><a href="tel:786-875-864-75"><span class="icon flaticon-telephone"></span> +91 95000 42144</a></li>
						</ul>
					</div>
					
					<!-- Top Right -->
                    <div class="top-right pull-right">
						<!-- Social Box -->
						<ul class="social-box">
							<li><a href="#" class="fa fa-facebook-f"></a></li>
							<li><a href="#" class="fa fa-twitter"></a></li>
							<li><a href="#" class="fa fa-dribbble"></a></li>
							<li><a href="#" class="fa fa-google"></a></li>
						</ul>
                    </div>
					
                </div>
            </div>
        </div>
		
		<!--Header-Upper-->
        <div class="header-upper">
        	<div class="auto-container clearfix">
            	
				<div class="pull-left logo-box" style="margin-top:15px;">
				 <span style="font-size: 25px; font-weight: bold;"><label style="color: #007bff">S</label>harpener <label style="color: #007bff">T</label>echnology</span></div>
				
				
				<div class="nav-outer clearfix">
					<!--Mobile Navigation Toggler-->
					<div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
					<!-- Main Menu -->
					<nav class="main-menu navbar-expand-md">
						<div class="navbar-header">
							<!-- Toggle Button -->    	
							<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						
						<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
							<ul class="navigation clearfix">
								<li><a href="<?php echo base_url();?>Welcome">Home</a>
								
								</li>
								<li><a href="<?php echo base_url();?>Welcome/about">About</a>
									
								</li>
								<li><a href="<?php echo base_url();?>Welcome/services">Services</a></li>
								
								<!-- <li><a href="enquiry.html">Enquiry</a></li> -->
							
								<li><a href="<?php echo base_url();?>Welcome/contact">Contact us</a></li>
								<!-- <li><a href="<?php echo base_url();?>Welcome/login">Open ticket  </a></li> -->
								<li><a href="<?php echo base_url();?>Welcome/login">Login</a></li>
								<!-- <li> 
								<form action="<?php echo base_url();?>Welcome/login">
   

								<button class="btn btn-primary  "   value="Go to Google"  type="submit" >Login </button>
									mt-4
								
								</form>
								</li> -->


							</ul>
						</div>
					</nav>
					
					<!-- Main Menu End-->
		
				</div>
				
            </div>
        </div>
        <!--End Header Upper-->
        
		<!-- Sticky Header  -->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                   <span style="font-size: 25px; font-weight: bold;"><label style="color: #007bff">S</label>harpener <label style="color: #007bff">T</label>echnology</span>
                </div>
                <!--Right Col-->
                <div class="pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <!--Keep This Empty / Menu will come through Javascript-->
                    </nav><!-- Main Menu End-->
					
					<!-- Main Menu End-->
				
					
                </div>
            </div>
        </div><!-- End Sticky Menu -->
    
		<!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><span class="icon flaticon-multiply"></span></div>
            
            <nav class="menu-box">
               <span style="font-size: 25px; font-weight: bold;"><label style="color: #007bff">S</label>harpener <label style="color: #007bff">T</label>echnology</span>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
            </nav>
        </div><!-- End Mobile Menu -->
	
    </header>    <!-- End Main Header -->
	
	<!-- Sidebar Cart Item -->
	
	<!-- END sidebar widget item -->