<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>sharpenertechnologyservices</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url();?>assets/assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="<?php echo base_url();?>assets/assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="<?php echo base_url();?>assets/assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url();?>assets/assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url();?>assets/assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

	
<link rel="shortcut icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">

<style>
.label {
  color: white;
  padding: 8px;
  font-family: Arial;
}
.success {background-color: #04AA6D;} /* Green */
.info {background-color: #2196F3;} /* Blue */
.warning {background-color: #ff9800;} /* Orange */
.danger {background-color: #f44336;} /* Red */ 
.other {background-color: #e7e7e7; color: black;} /* Gray */ 
</style>
</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="<?php echo base_url();?>assets/assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
            &nbsp;
            <br>
            &nbsp;

				<!-- <span style="font-size: 25px; font-weight: bold;"><label style="color: #007bff">S</label>harpener <br> <label style="color: #007bff">T</label>echnology</span> -->
            </div>

            <ul class="nav">
            <li >
                    <a href="<?php echo base_url();?>Welcome/custdash">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/custser">
                    <i class="pe-7s-note2"></i>
                        <p> Service Request  </p>
                    </a>
                </li>

                <li class="active">
                    <a href="<?php echo base_url();?>Welcome/custiket">
                    <i class="pe-7s-ticket"></i>
                        <p>Open Ticket </p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/cusvietik">
                    <i class="pe-7s-bandaid"></i>
                        <p>View  tickets </p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/cusvietikstatus">
                        <i class="pe-7s-timer"></i>
                        <p>Ticket status</p>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>Welcome/cpayment">
                        <i class="pe-7s-wallet"></i>
                        <p>Payments</p>
                    </a>
                </li>
               
				<!-- <li class="active-pro">
                    <a href="upgrade.html">
                        <i class="pe-7s-rocket"></i>
                        <p>Upgrade to PRO</p>
                    </a>
                </li> -->
            </ul>
    	</div>
    </div>

    <div class="main-panel">
    <?php include('adminheadercust.php');?>


      














        &nbsp;
            <br>
            <br>
            
            &nbsp;
        
      
            <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="header">
                                <h4 style=" font-family:verdana;" class="title">Open Ticket </h4>
                            </div>
                            <div class="content">
                           

                            <form method="POST" action= "<?=base_url('store-image')?>" enctype="multipart/form-data">
                                <!-- <form method="POST" action="<?php echo base_url();?>Welcome/tickregister"> -->
                                 

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> Name</label>
                                                <input type="text" class="form-control" placeholder="Enter your  Name " name="name" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email </label>
                                                <input type="email" class="form-control" placeholder="Email address" name="email" value= "<?php echo $this->session->userdata('user');?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Phone number  </label>
                                                <input type="text" class="form-control" placeholder="10 Digit Mobile number" name="phone"  pattern="[1-9]{1}[0-9]{9}"  required>
                                            </div>
                                        </div>
                                      
                                    </div>

                                

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Subject </label>
                                                <input type="text" class="form-control" placeholder="Enter the Subject here " name="subj" required>
                                               
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Department </label>
                                               

                                                <select type="text" class="form-control"   placeholder="City" name="dept" required >
                                                <option value="none" selected disabled hidden>Choose a Department </option>
                                                <option value = "Sales"> Sales / Marketing
                                                    </option>
                                                    <option value = "General Inquires"> General Inquires
                                                    </option>
                                                    <option value = "Billing/Fund"> Billing / Fund
                                                    </option>
                                                    <option value = "Server & Security"> Server & Security
                                                    </option>
                                                    <option value = "Product development">  Product development
                                                    </option>
                                                   
                                                    </select>




                                                
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Related Service </label>
                                                <input type="text" class="form-control" placeholder="specify product" name="service"  required>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Priority</label>
                                                <select type="text" class="form-control"   placeholder="City" name="priority" required>
                                                <option value="none" selected disabled hidden>Choose the Priority </option>
                                                <option value = "low"> Low
                                                </option>
                                                <option value = "Medium"> Medium
                                                </option>
                                                <option value = "high"> High
                                                </option>

                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                 


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label> Message</label>
                                                <textarea rows="5" class="form-control" placeholder="Here can be your description" name="message" required></textarea>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Attachments  </label>
                                                <input type="file" class="form-control"   id="profile_image" name="profile_image" size="33">
                                               
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" value="Upload Image" class="btn btn-info btn-fill pull-left">Submit</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                   

                </div>
            </div>
        </div>
              

            


       

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="<?php echo base_url();?>assets/assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="<?php echo base_url();?>assets/assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="<?php echo base_url();?>assets/assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="<?php echo base_url();?>assets/assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="<?php echo base_url();?>assets/assets/js/demo.js"></script>

	
</html>
