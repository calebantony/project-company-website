<?php include('header.php');?>
	
	<!--Page Title-->
    <section class="page-title">
		<div class="pattern-layer-one" style="background-image: url(<?php echo base_url();?>images/background/pattern-16.png)"></div>
    	<div class="auto-container">
			<h2>Services</h2>
			<ul class="page-breadcrumb">
				<li><a href="index-2.html">home</a></li>
				<li>Services</li>
			</ul>
        </div>
    </section>
    <!--End Page Title-->
	<section class="services-page-section">
		<div class="auto-container">
			<div class="row clearfix">
				
				<!-- News Block Three -->
				<div class="news-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image">
							<a href="services-detail.html"><img src="<?php echo base_url();?>images/resource/news-5.jpg" alt="" /></a>
						</div>
						<div class="lower-content">
							<div class="content">
								<div class="icon-box">
									<span class="icon flaticon-coding-1"></span>
								</div>
								<h4><a href="services-detail.html">Web Development</a></h4>
								<div class="text">We carry more than just good coding skills. Our experience makes us stand out from other web development.</div>
								<a class="read-more" href="services-detail.html">Read More<span class="arrow flaticon-long-arrow-pointing-to-the-right"></span></a>
							</div>
						</div>
					</div>
				</div>
				
				<!-- News Block Three -->
				<div class="news-block-three style-two col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="lower-content">
							<div class="content">
								<div class="icon-box">
									<span class="icon flaticon-mobile-app"></span>
								</div>
								<h4><a href="services-detail.html">Web Development</a></h4>
								<div class="text">We carry more than just good coding skills. Our experience makes us stand out from other web development.</div>
								<a class="read-more" href="services-detail.html">Read More<span class="arrow flaticon-long-arrow-pointing-to-the-right"></span></a>
							</div>
						</div>
						<div class="image">
							<a href="services-detail.html"><img src="<?php echo base_url();?>images/resource/news-6.jpg" alt="" /></a>
						</div>
					</div>
				</div>
				
				<!-- News Block Three -->
				<div class="news-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image">
							<a href="services-detail.html"><img src="<?php echo base_url();?>images/resource/news-7.jpg" alt="" /></a>
						</div>
						<div class="lower-content">
							<div class="content">
								<div class="icon-box">
									<span class="icon flaticon-computer"></span>
								</div>
								<h4><a href="services-detail.html">UI/UX Design</a></h4>
								<div class="text">Build the product you need on time with an experienced team that uses a clear and effective design process.</div>
								<a class="read-more" href="services-detail.html">Read More<span class="arrow flaticon-long-arrow-pointing-to-the-right"></span></a>
							</div>
						</div>
					</div>
				</div>
				
				<!-- News Block Three -->
				<div class="news-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image">
							<a href="services-detail.html"><img src="<?php echo base_url();?>images/resource/news-11.jpg" alt="" /></a>
						</div>
						<div class="lower-content">
							<div class="content">
								<div class="icon-box">
									<span class="icon flaticon-web"></span>
								</div>
								<h4><a href="services-detail.html">QA & Testing</a></h4>
								<div class="text">Turn to our experts to perform comprehensive, multi-stage testing and auditing of your software.</div>
								<a class="read-more" href="services-detail.html">Read More<span class="arrow flaticon-long-arrow-pointing-to-the-right"></span></a>
							</div>
						</div>
					</div>
				</div>
				
				<!-- News Block Three -->
				<div class="news-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image">
							<a href="services-detail.html"><img src="<?php echo base_url();?>images/resource/news-12.jpg" alt="" /></a>
						</div>
						<div class="lower-content">
							<div class="content">
								<div class="icon-box">
									<span class="icon flaticon-monitor-2"></span>
								</div>
								<h4><a href="services-detail.html">IT Consultancy</a></h4>
								<div class="text">Turn to our experts to perform comprehensive, multi-stage testing and auditing of your software.</div>
								<a class="read-more" href="services-detail.html">Read More<span class="arrow flaticon-long-arrow-pointing-to-the-right"></span></a>
							</div>
						</div>
					</div>
				</div>
				
				<!-- News Block Three -->
				<div class="news-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image">
							<a href="services-detail.html"><img src="<?php echo base_url();?>images/resource/news-13.jpg" alt="" /></a>
						</div>
						<div class="lower-content">
							<div class="content">
								<div class="icon-box">
									<span class="icon flaticon-human-resources"></span>
								</div>
								<h4><a href="services-detail.html">Dedicated Team</a></h4>
								<div class="text">Over the past decade, our customers succeeded by leveraging Intellectsoft’s process of building, motivating.</div>
								<a class="read-more" href="services-detail.html">Read More<span class="arrow flaticon-long-arrow-pointing-to-the-right"></span></a>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- About Section -->
	
	<!-- End About Section -->
	
	<!-- Counter Section -->

	<!-- End Counter Section -->
	
	<!-- About Section Two -->

	<!-- End About Section Two -->
	
	<!--Sponsors Section-->
	
	<!--End Sponsors Section-->
	

	<!-- End Process Section -->
	

	<!-- End Technology Section -->
	
	<!-- Experiance Section -->
	
	<!-- End Experiance Section -->
	
	<!-- Info Section -->

	<!-- End Info Section -->
	
	<!-- Main Footer -->
     <footer class="main-footer">
		<div class="pattern-layer-one" style="background-image: url(<?php echo base_url();?>images/background/pattern-7.png)"></div>
		<div class="pattern-layer-two" style="background-image: url(<?php echo base_url();?>images/background/pattern-8.png)"></div>
		<!--Waves end-->
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!-- Footer Column -->
                            <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
									<div class="logo">
										</a>
									</div>
									<div class="text">We are the best world Information Technology Company. Providing the highest quality in hardware & Network solutions. About more than 25 years of experience and 1000 of innovative achievements.</div>
									<!-- Social Box -->
									<ul class="social-box">
										<li><a href="#" class="fa fa-facebook-f"></a></li>
										<li><a href="#" class="fa fa-linkedin"></a></li>
										<li><a href="#" class="fa fa-twitter"></a></li>
										<li><a href="#" class="fa fa-google"></a></li>
									</ul>
								</div>
							</div>
							
							<!-- Footer Column -->
                            <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h5>Quick Links</h5>
									<ul class="list-link">
										<li><a href="#">Managed IT services</a></li>
										<li><a href="#">Cloud Services</a></li>
										<li><a href="#">IT support & helpdesk</a></li>
										<li><a href="#">Cyber security</a></li>
										<li><a href="#">Custom Software</a></li>
										<li><a href="#">Free Consultation</a></li>
										<li><a href="#">Our Business Growth</a></li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
					<!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							
							<!-- Footer Column -->
					
							
							<!-- Footer Column -->
							<div class="footer-column col-lg-6 col-md-6 col-sm-12">
								<div class="footer-widget contact-widget">
									<h5>Contact Us</h5>
									<ul>
										<li>
											<span class="icon flaticon-placeholder-2"></span>
											<strong>Address</strong>
											#4/129, 1'st Main Road,Alwarthirunagar Annexe, Chennai-600 087
										</li>
										<li>
											<span class="icon flaticon-phone-call"></span>
											<strong>Phone</strong>
											<a href="tel:+786-875-864-75">+91 95000 42144</a>
										</li>
										<li>
											<span class="icon flaticon-email-1"></span>
											<strong>E-Mail</strong>
											<a href="mailto:support@sharpnertechnologies.com">support@sharpnertechnologies.com</a>
										</li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
			
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="auto-container">
					<div class="row clearfix">
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<div class="copyright">Copyright &copy; 2020 . All Rights Reserved.</div>
						</div>
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<ul class="footer-nav">
								<li><a href="#">About Us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Privacy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</footer>	
	
</div>
<!--End pagewrapper-->

<!-- Color Palate / Color Switcher -->



<!-- Search Popup -->

<!-- End Header Search -->

<!--Scroll to top-->
<?php include('footer.php');?>