<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>sharpenertechnologyservices</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url();?>assets/assets/css/dash1//bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="<?php echo base_url();?>assets/assets/css/dash1/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="<?php echo base_url();?>assets/assets/css/dash1/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url();?>assets/assets/css/dash1/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url();?>assets/assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

	
<link rel="shortcut icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">


</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="<?php echo base_url();?>assets/assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
            &nbsp;
            <br>
            &nbsp;

				<!-- <span style="font-size: 25px; font-weight: bold;"><label style="color: #007bff">S</label>harpener <br> <label style="color: #007bff">T</label>echnology</span> -->
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="<?php echo base_url();?>Welcome/custdash">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/custser">
                    <i class="pe-7s-note2"></i>
                        <p> Service Request  </p>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>Welcome/custiket">
                    <i class="pe-7s-ticket"></i>
                        <p>Open Ticket </p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/cusvietik">
                    <i class="pe-7s-bandaid"></i>
                        <p>View  tickets </p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/cusvietikstatus">
                        <i class="pe-7s-timer"></i>
                        <p>Ticket status</p>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>Welcome/cpayment">
                        <i class="pe-7s-wallet"></i>
                        <p>Payments</p>
                    </a>
                </li>

                        


             
				<!-- <li class="active-pro">
                    <a href="upgrade.html">
                        <i class="pe-7s-rocket"></i>
                        <p>Upgrade to PRO</p>
                    </a>
                </li> -->
            </ul>
    	</div>
    </div>

    <div class="main-panel">
    <?php include('adminheadercust.php');?>

      














        &nbsp;
            <br>
            <br>
            
            &nbsp;
        
      

            <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <!-- <h4 style=" font-family:verdana;" class="title">Open Ticket </h4> -->
                                <h4 class="title"><b> HELP  DESK </b></h4>
                                <!-- <p class="category">The Record found</p> -->
                            </div>
                            <div class="content">
                           

                           
                                <form method="POST" action="<?php echo base_url();?>Welcome/showtick">
                            

                                  <div class="row">
                                        
                                        <div class="col-md-2">
                                            <div class="form-group" style="display:flex; flex-direction: row; justify-content: center; align-items: center" >
                                               
                                            
                                            <button type="submit" formaction="<?php echo base_url();?>Welcome/custiket" class="btn btn-success">Raise New Ticket</button> 
                                              
                                                
                                                <!-- <input type="text" disabled="" class="form-control" value="" name="phone" > -->
                                               
                                               
                                            </div>
                                        </div>




                                        <div class="col-md-2">
                                            <div class="form-group" style="display:flex; flex-direction: row; justify-content: center; align-items: center" >
                                               
                                           <br> </br>
                                           
                                               
                                            </div>
                                        </div>



                                        <div class="col-md-2">
                                            <div class="form-group" style="display:flex; flex-direction: row; justify-content: center; align-items: center" >
                                               
                                            <input type="text" class="form-control" placeholder=" Ticket ID" name="tid"  >
                                           
                                            </div>
                                        </div>



                                        <div class="col-md-1">
                                            <div class="form-group" style="display:flex; flex-direction: row; justify-content: center; align-items: center" >
                                               
                                            <!-- <input type="text" class="form-control" placeholder="Mobile number" name="phone"  value=""> -->
                                            <button type="submit"  class="btn btn-success">Search</button> 
                                              
                                            </div>
                                        </div>

                                      
                                    </div>

                                 
                                   
                                    



                                    <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>ID</th>
                                    	<th>Department</th>
                                        <th>Subject </th>
                                    	<th>Submitter</th>
                                    	<th>Status</th>
                                        <th> Related Service</th>
                                        <!-- <th>Choose </th> -->
                                       

                                    </thead>
                                    <tbody>
                                    <?php
                        foreach($emp as $e)
                        {?>
                        <tr>
                        <td><?php echo $e['tid'];?></td>
                        <td><?php echo $e['department'];?></td>
                        <td> <?php echo $e['subject'];?> </td>
                        <td><?php echo $e['usrname'];?></td>
                        <td><?php echo $e['service'];?></td>
                        <td><?php echo $e['status'];?></td>
                      
                        <!-- <td>
                         <a href ="<?php echo base_url();?>Welcome/showtickreply/<?php echo $e['tid'];?>">Action</a></td> -->


                         <!-- <td>
                         <form name="f2" action="<?php echo base_url();?>Welcome/showtickreply/<?php echo $e['tid'];?>" >
                          <button  type="submit"  class="btn"><i class="fa fa-eye"></i> View</button> 
                          </form>
                          </td> -->


                        </tr>



                        <?php } ?>
                                    </tbody>
                                </table>

                            </div>







                                   
                                   
                                   
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                   

                </div>
            </div>
        </div>
              
      

            


       

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="<?php echo base_url();?>assets/assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="<?php echo base_url();?>assets/assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="<?php echo base_url();?>assets/assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="<?php echo base_url();?>assets/assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="<?php echo base_url();?>assets/assets/js/demo.js"></script>

	
</html>
